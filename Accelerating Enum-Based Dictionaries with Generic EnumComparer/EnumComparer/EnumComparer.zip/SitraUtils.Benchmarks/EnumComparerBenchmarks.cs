﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace SitraUtils.Benchmarks
{
    public class EnumComparerBenchmarks
    {
        const int MAX_DAY_OF_WEEK = (int)DayOfWeek.Saturday;
        const int ITERATIONS = 1000000;
        public static void Main()
        {
            var lcgEnumComparer =
                runFunc("building Generic LCG.EnumComparer ",
                        i => LCG.EnumComparer<DayOfWeek>.Instance, 1);
            var enumComparer =
                runFunc("building Generic EnumComparer     ",
                        i => EnumComparer<DayOfWeek>.Instance, 1);
            var dayOfWeekComparer =
                runFunc("building hand-written EnumComparer",
                        i => new DayOfWeekComparer(), 1);

            runAction("Dictionary with Generic LCG.EnumComparer      ",
                      i => populateDictionary(new Dictionary<DayOfWeek, int>(lcgEnumComparer), i), ITERATIONS);

            runAction("Dictionary with Generic EnumComparer          ",
                      i => populateDictionary(new Dictionary<DayOfWeek, int>(enumComparer), i), ITERATIONS);

            runAction("Dictionary with hand-written DayOfWeekComparer",
                      i => populateDictionary(new Dictionary<DayOfWeek, int>(dayOfWeekComparer), i), ITERATIONS);

            runAction("Dictionary with default comparer              ",
                      i => populateDictionary(new Dictionary<DayOfWeek, int>(), i), ITERATIONS);

            runAction("Dictionary of ints                            ",
                      i => populateDictionary(new Dictionary<int, int>(), i), ITERATIONS);

            Console.ReadLine();
        }

        private static void runAction(string desc, Action<int> action, int iters)
        {
            action(iters);
            var stopwatch = new Stopwatch();
            var elapsed = new TimeSpan();
            const int RUNS = 3;
            for (var i = 0; i < RUNS; i++ )
            {
                stopwatch.Start();
                action(iters);
                stopwatch.Stop();
                elapsed += stopwatch.Elapsed;
                stopwatch.Reset();
            }
            elapsed = TimeSpan.FromTicks(elapsed.Ticks / RUNS);
            double ticksPerSec = TimeSpan.FromSeconds(1).Ticks;
            Console.WriteLine(desc + ": {0:N1} ms ({1:N0} hz)",
                              elapsed.TotalMilliseconds, iters * ticksPerSec / elapsed.Ticks);
        }
        private static T runFunc<T>(string desc, Func<int, T> func, int iters)
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();
            var result = func(iters);
            stopwatch.Stop();
            double ticksPerSec = TimeSpan.FromSeconds(1).Ticks;
            Console.WriteLine(desc + ": {0:N1} ms ({1:N0} hz)",
                              stopwatch.Elapsed.TotalMilliseconds, iters * ticksPerSec / stopwatch.ElapsedTicks);
            return result;
        }

        private static void populateDictionary(Dictionary<DayOfWeek, int> map, int iters)
        {
            for (var i = 0; i < iters; i++)
            {
                var key = (DayOfWeek)(i % MAX_DAY_OF_WEEK);
                map[key] = i;
            }
        }
        private static void populateDictionary(Dictionary<int, int> map, int iters)
        {
            for (var i = 0; i < iters; i++)
            {
                var key = (i % MAX_DAY_OF_WEEK);
                map[key] = i;
            }
        }
    }
}
